Changing IP and Domain in file odoo.conf before running bash script.

